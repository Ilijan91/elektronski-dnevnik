<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

?>
<div class="site-error container main">

    <h1>Error!</h1>

    <div class="alert alert-danger">
    <h3><?= $msg?></h3>
    </div>

</div>